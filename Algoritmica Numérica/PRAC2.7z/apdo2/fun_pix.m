function [F,J]= fun_pix(X)
global ctrl_3D ctrl_PX ctrl_PY
% X = vector columna 6x1 con la posicion/orientaci�n c�mara
% F = vector columna con los residuos en puntos de control

% Calculo de F (vector de residuos)
 

% Aproximacion a la matriz J
  

return