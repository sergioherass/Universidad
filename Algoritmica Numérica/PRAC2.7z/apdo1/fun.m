function [F,J]=fun(X)

x=X(1); y=X(2); %Extraemos componentes x,y del vector X

% Evaluacion de F (vector COLUMNA)


if nargout==1, return; end

% Evaluar aproximaci�n matriz J          


 

end