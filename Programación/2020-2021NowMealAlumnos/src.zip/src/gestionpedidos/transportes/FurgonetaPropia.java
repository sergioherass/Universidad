package gestionpedidos.transportes;

import gestionpedidos.mapa.Mapa;

public class FurgonetaPropia extends Furgoneta{
	private double velocidadMedia = 30;
	private static final double EUROS_P_HORA = 40;
	
	
	public FurgonetaPropia(String codigo, Mapa mapa, double tara) {
		//herencia
		super(codigo, mapa, tara);
	}
	
	public FurgonetaPropia() {
		
	}

	public double getVelocidadmedia() {
		return velocidadMedia;
	}
	
	public void setVelocidadmedia(double velocidadmedia){
		this.velocidadMedia = velocidadmedia;
	}
	public double coste(String codPosOrigen, String codPosDestino) {
		
		if(getTara()<500) {
			return super.getMapa().distancia(codPosOrigen, codPosDestino)*EUROS_P_HORA/velocidadMedia;
		} else {
			return super.getMapa().distancia(codPosOrigen, codPosDestino)*EUROS_P_HORA/velocidadMedia*1.10;

		}
		
	}

	
}
