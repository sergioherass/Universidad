package gestionpedidos.transportes;

import gestionpedidos.mapa.Mapa;
import list.IList;
public abstract class Transporte {
	
private String codigo;
private Mapa mapa;

protected Transporte (String codigo, Mapa mapa) {
	
	this.codigo = codigo;
	this.mapa = mapa;

}
public Transporte() {
	
}


public String getCodigo() {
	return codigo;
}



public double coste(String codPosDestino) {
	if(this instanceof Moto) {
		return coste(getCodigo(),codPosDestino);
	}
	else if (this instanceof FurgonetaPropia) {
		return coste (getCodigo(),codPosDestino);
	}
	else {
		return coste(codigo, codPosDestino);
	}
	
}
public abstract double coste(String codPosOrigen, String codPosDestino);

protected Mapa getMapa() {
	return mapa;
}

}
