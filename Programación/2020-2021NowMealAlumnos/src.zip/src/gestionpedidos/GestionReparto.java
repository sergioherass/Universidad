package gestionpedidos;

import gestionpedidos.excepciones.PedidoSinTransporteAsignado;
import gestionpedidos.mapa.Mapa;
import gestionpedidos.mapa.PosicionXY;
import gestionpedidos.pedido.Pedido;
import gestionpedidos.transportes.Transporte;

public class GestionReparto {
	// C�DIGO DE APOYO
	private GestionRepartoLocal[] gestoresLocales;
	private Mapa mapa;

	//C�DIGO DE APOYO
	public Mapa getMapa() {
		return mapa;
	}

	// C�DIGO DE APOYO
	public String getEstadoGestorLocal(int i){
		return this.gestoresLocales[i].getDisponibles() + this.gestoresLocales[i].getEsperando();
	}

	// C�DIGO DE APOYO
	public String getEstadoGestorLocalNum(int i){
		return this.gestoresLocales[i].getCodMotosDisponibles().size() + ";" +
				this.gestoresLocales[i].getCodFurgoDisponibles().size() + ";" +
				this.gestoresLocales[i].getCodEsperandoMoto().size() + ";" +
				this.gestoresLocales[i].getCodEsperandoFurgo().size() ;
	}

	public GestionReparto(Mapa mapa){
		
		gestoresLocales = new GestionRepartoLocal[4];
		gestoresLocales[0]= new GestionRepartoLocal();
		gestoresLocales[1]= new GestionRepartoLocal();
		gestoresLocales[2]= new GestionRepartoLocal();
		gestoresLocales[3]= new GestionRepartoLocal();
		
		this.mapa = mapa;
		
	}
	
	public void addTransporteLocalidad(Transporte transporte) {
		for (int i = 0; i < gestoresLocales.length; i++) {
			if (gestoresLocales[i] == gestoresLocales[0]) {
				gestoresLocales[0].add(transporte);
			} else if (gestoresLocales[i] == gestoresLocales[1]) {
				gestoresLocales[1].add(transporte);
			} else if (gestoresLocales[i] == gestoresLocales[2]) {
				gestoresLocales[2].add(transporte);
			} else if (gestoresLocales[i] == gestoresLocales[3]) {
				gestoresLocales[3].add(transporte);
			}

		}
	}

	private int seleccionarLocalidad(PosicionXY pos){
//		hacer algo
		
		return 0;
	}

	public void asignarPedido(Pedido pedido) {
		for (int i = 0; i < gestoresLocales.length; i++) {
			if (gestoresLocales[i] == gestoresLocales[0]) {
				gestoresLocales[0].asignarPedido(pedido);
			} else if (gestoresLocales[i] == gestoresLocales[1]) {
				gestoresLocales[1].asignarPedido(pedido);
			} else if (gestoresLocales[i] == gestoresLocales[2]) {
				gestoresLocales[2].asignarPedido(pedido);
			} else if (gestoresLocales[i] == gestoresLocales[3]) {
				gestoresLocales[3].asignarPedido(pedido);
			}

		}
	}
	

	public void notificarEntregaPedido(Pedido pedido) throws PedidoSinTransporteAsignado{
		for (int i = 0; i < gestoresLocales.length; i++) {
			if (gestoresLocales[i] == gestoresLocales[0]) {
				gestoresLocales[0].notificarEntregaPedido(pedido);
			} else if (gestoresLocales[i] == gestoresLocales[1]) {
				gestoresLocales[1].notificarEntregaPedido(pedido);
			} else if (gestoresLocales[i] == gestoresLocales[2]) {
				gestoresLocales[2].notificarEntregaPedido(pedido);
			} else if (gestoresLocales[i] == gestoresLocales[3]) {
				gestoresLocales[3].notificarEntregaPedido(pedido);
			}

		}
	}
	

}
